var swiper = new Swiper('.main-swiper', {
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
  },
  pagination: {
      el: '.swiper-pagination',
      type: 'bullets',
  },
  autoplay: {
      delay: 10,
  },
  speed: 10,
});
